package com.onyx.onyxinstitutbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnyxInstitutBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnyxInstitutBackendApplication.class, args);
	}

}
