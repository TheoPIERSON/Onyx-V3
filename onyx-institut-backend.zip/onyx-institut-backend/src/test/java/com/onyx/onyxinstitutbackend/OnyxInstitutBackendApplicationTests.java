package com.onyx.onyxinstitutbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnyxInstitutBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
